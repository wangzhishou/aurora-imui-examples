package cn.jiguang.imui.chatinput.listener;


public interface CameraEventListener {
    void onFinishTakePicture();
}
