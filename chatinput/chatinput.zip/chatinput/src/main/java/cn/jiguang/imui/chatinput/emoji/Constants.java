package cn.jiguang.imui.chatinput.emoji;

public class Constants {

    public static int EMOTICON_CLICK_TEXT = 1;
    public static int EMOTICON_CLICK_BIGIMAGE = 2;
}
